It is recommended to run the program by running exec.bat rather than just double clicking on the .jar file
Do not manually alter any of the files, that means no name changes or content changes without doing so directly through the program

Some notes on how the gallery works:
   -Images are saved by saving the filepath of the image's original location
   -This means that you cannot change the location of the image once you upload it if you want it stay in the gallery
   -I recommend using a central folder for all gallery images in order to prevent this from happening on accident(One is provided if you choose to use it)

If you see a long block of text in the console resembling an error DO NOT WORRY as your program will still work as intended, 
all harmful errors have been ironed out to my knowledge