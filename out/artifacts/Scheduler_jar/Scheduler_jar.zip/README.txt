It is recommended to run the program by running exec.bat rather than just double clicking on the .jar file
Do not manually alter any of the files 